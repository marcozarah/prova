<?php

$this->resource('prova', 'NotaController', ['except' => ['create', 'edit']]);
