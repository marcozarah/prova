<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title>Prova</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>" />
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>

<script type="text/javascript" src="<?php echo e(url('js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>


<?php echo $__env->yieldContent('script'); ?>
</body>
</html>