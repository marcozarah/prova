@extends('template')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 text-right">
            <button type="button" class="btn btn-success mt-3 mb-3"  data-toggle="modal" data-target="#modalExemplo" id="insereNota">Inserir Nota</button>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table-dashed table table-condensed">
                <thead>
                    <tr>
                        <th>Titulo</th>
                        <th>Nota</th>
                        <th>Categoria</th>
                        <th>Data Criação</th>
                        <th>Editar</th>
                        <th>Deletar</th>
                    </tr>
                </thead>
                <tbody id="corpo">
                @foreach($resultSet as $idx => $value)
                    <tr>
                        <td>{{$value->titulo}}</td>
                        <td>{{$value->nota}}</td>
                        <td>{{$value->categoria}}</td>
                        <td>{{$value->created_at}}</td>
                        <td><button class="btn btn-warning" id="Editar{{$value->id}}" onClick="Editar({{$value->id}})"  data-toggle="modal" data-target="#modalEditar">Editar</button></td>
                        <td><button class="btn btn-danger" id="Deletar{{$value->id}}" onClick="Deletar({{$value->id}})">Deletar</button></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>



 <div class="modal fade" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Título do modal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-12">
                <label>Título<br>
                    <input type="text" class="form-control" id="titulo-insert" required="required" />
                </label>
            </div>
            <div class="col-md-12">
                <label>Nota<br>
                    <input type="text" class="form-control" id="nota-insert" required="required" />
                </label>
            </div>
            <div class="col-md-12">
                <label>Categoria<br>
                    <select id="categoria-insert" class="form-control" require="required">
                        <option value="pessoal">Pessoal</option>
                        <option value="trabalho">Trabalho</option>
                    </select>
                </label>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <button type="button" class="btn btn-info" onClick="inserirSuccess();">Salvar mudanças</button>
      </div>
    </div>
  </div>
</div> 




<div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Título do modal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-12">
                <label>Título<br>
                    <input type="text" class="form-control" id="titulo-edit" required="required" />
                </label>
            </div>
            <div class="col-md-12">
                <label>Nota<br>
                    <input type="text" class="form-control" id="nota-edit" required="required" />
                </label>
            </div>
            <div class="col-md-12">
                <label>Categoria<br>
                    <select id="categoria-edit" class="form-control" require="required">
                        <option value="pessoal">Pessoal</option>
                        <option value="trabalho">Trabalho</option>
                    </select>
                    <input type="hidden" name="id" value="" id="id_hidden" />
                </label>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <button type="button" class="btn btn-info" onClick="EditaExe();">Salvar mudanças</button>
      </div>
    </div>
  </div>
</div> 


@endsection

@section('script')
@parent
<script>

function dE(id){
    return document.getElementById(id);
}


function Deletar(id){
    $.ajax({
        url:"{{url('api/prova')}}",
        type:"PUT",
        data:{id:id},
        success:function(resp){
            if(resp == 'ok'){
                preencheCorpo();
            }else{
                alert("Erro ao deletar.");
            }
        },
        error:function(xhr, error){
            console.log("xhr:"+xhr+", error:"+error);
        }
    });
}


function Editar(id){
    $.ajax({
        url:"{{url('api/prova')}}/"+id,
        type:"GET",
        data:{id:id},
        success:function(data){
            dE('titulo-edit').value    = data.titulo;
            dE('nota-edit').value      = data.nota;
            dE('categoria-edit').value = data.categoria;
            dE('id_hidden').value      = data.id;
        },
        error:function(xhr, error){
            console.log("XHR:"+xhr+", Error:"+error);
        }
    });
}


function EditaExe(){


    var titulo     =   dE('titulo-edit').value;
    var nota       =   dE('nota-edit').value;
    var categoria  =   dE('categoria-edit').value;
    var id_hidden  =   dE('id_hidden').value;

    dE('titulo-edit').value    = "";
    dE('nota-edit').value      = "";
    dE('categoria-edit').value = "";
    dE('id_hidden').value      = "";

    if(titulo != "" && nota != "" && categoria != ""){

        $.ajax({
            url:"{{url('api/prova')}}/" + id_hidden,
            type:"PUT",
            data:{titulo:titulo, nota:nota, categoria:categoria},
            success:function(data){
                preencheCorpo();
            }
        });
    }else{
        alert("Todos os dados são obrigatórios.");
    }
}

function inserirSuccess()
{
    var titulo    = dE('titulo-insert').value;
    var nota      = dE('nota-insert').value;
    var categoria = dE('categoria-insert').value;

    if(titulo != "" && nota != "" && categoria != ""){

        dE('titulo-insert').value = "";
        dE('nota-insert').value   = "";
        dE('categoria-insert').value = "";

        $.ajax({
            url:"{{url('api/prova')}}",
            type:"POST",
            data:{titulo:titulo,nota:nota,categoria:categoria},
            success:function(data){
                if(data.resp == 'ok'){
                     preencheCorpo();
                }else{
                    alert("Houve um erro  ao inserir.");
                }
            },
            error:function(xhr, erro){
                console.log("XHR:"+xhr+", ERRO:"+erro);
            } 
        });

    }else{
        alert("Todos os ítens são obrigatórios.");
    }
}

function preencheCorpo(){
    //dE('corpo').remove();
    $('#corpo').html("");
    $.ajax({
        url:"{{url('api/prova')}}",
        type:"GET",
        success:function(data){
            $('#modalExemplo').modal('hide');
            $("#modalEditar").modal('hide');
            var comprimento = data.length;
            var dobj = "";

            for(i=0;i<comprimento;i++)
            {
                //console.log("Registro:" + data[i] + "\n");
                dobj += "<tr>";
                dobj += "   <td>" + data[i].titulo + "</td><td>" + data[i].nota + "</td><td>" + data[i].categoria + "</td><td>" + data[i].created_at + "</td> ";
                dobj += "   <td><button class=\"btn btn-warning\" id=\"Editar"+data[i].id+"\" onClick=\"Editar(" + data[i].id + ")\"  data-toggle=\"modal\" data-target=\"#modalEditar\">Editar</button></td> ";
                dobj += "   <td><button class=\"btn btn-danger\" id=\"Deletar"+data[i].id+"\" onClick=\"Deletar("+data[i].id+")\">Deletar</button></td>";
                dobj += "</tr>";
            }

            $("#corpo").html(dobj);

           //dE('corpo').innerHTML = dobj;
        },
        error:function(xhr, erro){
            console.log("XHR: "+xhr+", ERRO:"+erro);
        }
    });
}


</script>
@stop