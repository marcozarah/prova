<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title>Prova</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}" />
</head>
<body>
@yield('content')

<script type="text/javascript" src="{{url('js/jquery-3.1.1.min.js')}}"></script>
<script src="{{url('js/bootstrap.min.js')}}"></script>


@yield('script')
</body>
</html>