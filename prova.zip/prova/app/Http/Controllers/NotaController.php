<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Nota;

class NotaController extends Controller
{

    protected $baseNota = NULL;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct(Nota $nta){
        $this->baseNota = $nta;
    }


    public function index()
    {
        //GET SEM ID
        $res = $this->baseNota->getAll();
        return response()->json($res, 200);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //POST
        $res = $this->baseNota->insert($request->all());

        if($res):
            return response()->json(['resp' => 'ok'], 200);
        else:
            return response()->json(["resp" => 'no'], 303);
        endif;

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //GET COM ID
        $res = $this->baseNota->find($id);
        if($res):
            return response()->json($res, 200);
        else:
            return response()->json(['resp' => 'erro'], 500);
        endif;
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //PUT
        $obj  = $this->baseNota->pegarPorId($id);
        $obj->titulo    = $request->titulo;
        $obj->nota      = $request->nota;
        $obj->categoria = $request->categoria;
        $res = $obj->save();

        if($res):
            return response()->json(['resp' => 'ok'], 200);
        else:
            return response()->json(['resp' => 'no'], 500);
        endif;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //DELETE
        $res = $this->baseNota->del($id);
        if($res):
            return response()->json(['resp' => 'ok'], 200);
        else:
            return response()->json(['resp' => 'no'], 500);
        endif;
    }
}
