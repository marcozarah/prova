<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Nota;

class HomeController extends Controller
{
    protected $nota = NULL;
    //
    public function __construct(Nota $n){
        $this->nota = $n;
    }
    public function index(){
        $resultSet = $this->nota->getAll();
        return view('index', compact('resultSet'));
    }
}
