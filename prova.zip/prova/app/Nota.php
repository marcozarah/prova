<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nota extends Model
{
    protected $fillable = [
        'titulo',
        'nota',
        'categoria',
        'created_at'
    ];
    //
    public function getAll(){
        return $this->select('*')->from('notas')->orderBy('id', 'DESC')->get();
    }

    public function insert($data)
    {
       return self::create($data);
    }

    public function del($id)
    {
        $registro = $this->getById($id);
        return $registro->destroy();
        
    }

    public function pegarPorId($id){
        return self::find($id);
    }

    private function getById($id){
        return self::find($id);
    } 
}
